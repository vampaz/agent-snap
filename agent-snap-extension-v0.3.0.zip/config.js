globalThis.__agentSnapUploadKey = "";
