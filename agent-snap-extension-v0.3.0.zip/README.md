# Extension Build Notes

Build the extension with `npm run build:ext`, `npm run build:ext:env`, or `npm run package:ext`.
